#define CFG_TOYBOX_CONTAINER 0
#define USE_TOYBOX_CONTAINER(...)
#define CFG_TOYBOX_FIFREEZE 0
#define USE_TOYBOX_FIFREEZE(...)
#define CFG_TOYBOX_ICONV 1
#define USE_TOYBOX_ICONV(...) __VA_ARGS__
#define CFG_TOYBOX_UTMPX 1
#define USE_TOYBOX_UTMPX(...) __VA_ARGS__
#define CFG_TOYBOX_SHADOW 0
#define USE_TOYBOX_SHADOW(...)
#define CFG_TOYBOX_ON_ANDROID 0
#define USE_TOYBOX_ON_ANDROID(...)
#define CFG_TOYBOX_ANDROID_SCHEDPOLICY 0
#define USE_TOYBOX_ANDROID_SCHEDPOLICY(...)
#define CFG_TOYBOX_FORK 1
#define USE_TOYBOX_FORK(...) __VA_ARGS__
#define CFG_TOYBOX_PRLIMIT 0
#define USE_TOYBOX_PRLIMIT(...)
#define CFG_TOYBOX_GETRANDOM 0
#define USE_TOYBOX_GETRANDOM(...)
#define CFG_TOYBOX_COPYFILERANGE 0
#define USE_TOYBOX_COPYFILERANGE(...)
#define CFG_TOYBOX_HASTIMERS 0
#define USE_TOYBOX_HASTIMERS(...)
#define CFG_BASENAME 1
#define USE_BASENAME(...) __VA_ARGS__
#define CFG_CAL 1
#define USE_CAL(...) __VA_ARGS__
#define CFG_CAT 1
#define USE_CAT(...) __VA_ARGS__
#define CFG_CAT_V 1
#define USE_CAT_V(...) __VA_ARGS__
#define CFG_CATV 1
#define USE_CATV(...) __VA_ARGS__
#define CFG_CHGRP 1
#define USE_CHGRP(...) __VA_ARGS__
#define CFG_CHOWN 1
#define USE_CHOWN(...) __VA_ARGS__
#define CFG_CHMOD 1
#define USE_CHMOD(...) __VA_ARGS__
#define CFG_CKSUM 1
#define USE_CKSUM(...) __VA_ARGS__
#define CFG_CRC32 1
#define USE_CRC32(...) __VA_ARGS__
#define CFG_CMP 1
#define USE_CMP(...) __VA_ARGS__
#define CFG_COMM 1
#define USE_COMM(...) __VA_ARGS__
#define CFG_CP 1
#define USE_CP(...) __VA_ARGS__
#define CFG_MV 1
#define USE_MV(...) __VA_ARGS__
#define CFG_INSTALL 0
#define USE_INSTALL(...)
#define CFG_CPIO 1
#define USE_CPIO(...) __VA_ARGS__
#define CFG_CUT 1
#define USE_CUT(...) __VA_ARGS__
#define CFG_DATE 1
#define USE_DATE(...) __VA_ARGS__
#define CFG_DF 1
#define USE_DF(...) __VA_ARGS__
#define CFG_DIRNAME 1
#define USE_DIRNAME(...) __VA_ARGS__
#define CFG_DU 1
#define USE_DU(...) __VA_ARGS__
#define CFG_ECHO 1
#define USE_ECHO(...) __VA_ARGS__
#define CFG_ENV 1
#define USE_ENV(...) __VA_ARGS__
#define CFG_EXPAND 1
#define USE_EXPAND(...) __VA_ARGS__
#define CFG_FALSE 1
#define USE_FALSE(...) __VA_ARGS__
#define CFG_FILE 1
#define USE_FILE(...) __VA_ARGS__
#define CFG_FIND 1
#define USE_FIND(...) __VA_ARGS__
#define CFG_GETCONF 1
#define USE_GETCONF(...) __VA_ARGS__
#define CFG_GREP 1
#define USE_GREP(...) __VA_ARGS__
#define CFG_EGREP 1
#define USE_EGREP(...) __VA_ARGS__
#define CFG_FGREP 1
#define USE_FGREP(...) __VA_ARGS__
#define CFG_HEAD 1
#define USE_HEAD(...) __VA_ARGS__
#define CFG_ICONV 1
#define USE_ICONV(...) __VA_ARGS__
#define CFG_ID 1
#define USE_ID(...) __VA_ARGS__
#define CFG_ID_Z 0
#define USE_ID_Z(...)
#define CFG_GROUPS 1
#define USE_GROUPS(...) __VA_ARGS__
#define CFG_LOGNAME 1
#define USE_LOGNAME(...) __VA_ARGS__
#define CFG_WHOAMI 1
#define USE_WHOAMI(...) __VA_ARGS__
#define CFG_KILL 1
#define USE_KILL(...) __VA_ARGS__
#define CFG_KILLALL5 1
#define USE_KILLALL5(...) __VA_ARGS__
#define CFG_LINK 1
#define USE_LINK(...) __VA_ARGS__
#define CFG_LN 1
#define USE_LN(...) __VA_ARGS__
#define CFG_LOGGER 1
#define USE_LOGGER(...) __VA_ARGS__
#define CFG_LS 1
#define USE_LS(...) __VA_ARGS__
#define CFG_MKDIR 1
#define USE_MKDIR(...) __VA_ARGS__
#define CFG_MKDIR_Z 0
#define USE_MKDIR_Z(...)
#define CFG_MKFIFO 1
#define USE_MKFIFO(...) __VA_ARGS__
#define CFG_MKFIFO_Z 0
#define USE_MKFIFO_Z(...)
#define CFG_NICE 1
#define USE_NICE(...) __VA_ARGS__
#define CFG_NL 1
#define USE_NL(...) __VA_ARGS__
#define CFG_NOHUP 1
#define USE_NOHUP(...) __VA_ARGS__
#define CFG_OD 1
#define USE_OD(...) __VA_ARGS__
#define CFG_PASTE 1
#define USE_PASTE(...) __VA_ARGS__
#define CFG_PATCH 1
#define USE_PATCH(...) __VA_ARGS__
#define CFG_PRINTF 1
#define USE_PRINTF(...) __VA_ARGS__
#define CFG_PS 0
#define USE_PS(...)
#define CFG_TOP 0
#define USE_TOP(...)
#define CFG_IOTOP 0
#define USE_IOTOP(...)
#define CFG_PGREP 0
#define USE_PGREP(...)
#define CFG_PKILL 0
#define USE_PKILL(...)
#define CFG_PWD 1
#define USE_PWD(...) __VA_ARGS__
#define CFG_RENICE 1
#define USE_RENICE(...) __VA_ARGS__
#define CFG_RM 1
#define USE_RM(...) __VA_ARGS__
#define CFG_RMDIR 1
#define USE_RMDIR(...) __VA_ARGS__
#define CFG_SED 1
#define USE_SED(...) __VA_ARGS__
#define CFG_SLEEP 1
#define USE_SLEEP(...) __VA_ARGS__
#define CFG_SORT 1
#define USE_SORT(...) __VA_ARGS__
#define CFG_SORT_FLOAT 1
#define USE_SORT_FLOAT(...) __VA_ARGS__
#define CFG_SPLIT 1
#define USE_SPLIT(...) __VA_ARGS__
#define CFG_STRINGS 1
#define USE_STRINGS(...) __VA_ARGS__
#define CFG_TAIL 1
#define USE_TAIL(...) __VA_ARGS__
#define CFG_TAR 1
#define USE_TAR(...) __VA_ARGS__
#define CFG_TEE 1
#define USE_TEE(...) __VA_ARGS__
#define CFG_TEST 1
#define USE_TEST(...) __VA_ARGS__
#define CFG_TEST_GLUE 1
#define USE_TEST_GLUE(...) __VA_ARGS__
#define CFG_TIME 1
#define USE_TIME(...) __VA_ARGS__
#define CFG_TOUCH 1
#define USE_TOUCH(...) __VA_ARGS__
#define CFG_TRUE 1
#define USE_TRUE(...) __VA_ARGS__
#define CFG_TTY 1
#define USE_TTY(...) __VA_ARGS__
#define CFG_ULIMIT 0
#define USE_ULIMIT(...)
#define CFG_ARCH 0
#define USE_ARCH(...)
#define CFG_LINUX32 0
#define USE_LINUX32(...)
#define CFG_UNAME 1
#define USE_UNAME(...) __VA_ARGS__
#define CFG_UNIQ 1
#define USE_UNIQ(...) __VA_ARGS__
#define CFG_UNLINK 1
#define USE_UNLINK(...) __VA_ARGS__
#define CFG_UUDECODE 1
#define USE_UUDECODE(...) __VA_ARGS__
#define CFG_UUENCODE 1
#define USE_UUENCODE(...) __VA_ARGS__
#define CFG_WC 1
#define USE_WC(...) __VA_ARGS__
#define CFG_WHO 1
#define USE_WHO(...) __VA_ARGS__
#define CFG_XARGS 1
#define USE_XARGS(...) __VA_ARGS__
#define CFG_ARP 0
#define USE_ARP(...)
#define CFG_ARPING 0
#define USE_ARPING(...)
#define CFG_BC 0
#define USE_BC(...)
#define CFG_BOOTCHARTD 0
#define USE_BOOTCHARTD(...)
#define CFG_BRCTL 0
#define USE_BRCTL(...)
#define CFG_CHSH 0
#define USE_CHSH(...)
#define CFG_CROND 0
#define USE_CROND(...)
#define CFG_CRONTAB 0
#define USE_CRONTAB(...)
#define CFG_DD 0
#define USE_DD(...)
#define CFG_DHCP 0
#define USE_DHCP(...)
#define CFG_DHCP6 0
#define USE_DHCP6(...)
#define CFG_DHCPD 0
#define USE_DHCPD(...)
#define CFG_DEBUG_DHCP 0
#define USE_DEBUG_DHCP(...)
#define CFG_DIFF 0
#define USE_DIFF(...)
#define CFG_DUMPLEASES 0
#define USE_DUMPLEASES(...)
#define CFG_EXPR 0
#define USE_EXPR(...)
#define CFG_FDISK 0
#define USE_FDISK(...)
#define CFG_FOLD 0
#define USE_FOLD(...)
#define CFG_FSCK 0
#define USE_FSCK(...)
#define CFG_GETFATTR 0
#define USE_GETFATTR(...)
#define CFG_GETOPT 0
#define USE_GETOPT(...)
#define CFG_GETTY 0
#define USE_GETTY(...)
#define CFG_GROUPADD 0
#define USE_GROUPADD(...)
#define CFG_GROUPDEL 0
#define USE_GROUPDEL(...)
#define CFG_HEXDUMP 0
#define USE_HEXDUMP(...)
#define CFG_HD 0
#define USE_HD(...)
#define CFG_INIT 0
#define USE_INIT(...)
#define CFG_IP 0
#define USE_IP(...)
#define CFG_IPCRM 0
#define USE_IPCRM(...)
#define CFG_IPCS 0
#define USE_IPCS(...)
#define CFG_KLOGD 0
#define USE_KLOGD(...)
#define CFG_KLOGD_SOURCE_RING_BUFFER 0
#define USE_KLOGD_SOURCE_RING_BUFFER(...)
#define CFG_LAST 0
#define USE_LAST(...)
#define CFG_LSOF 0
#define USE_LSOF(...)
#define CFG_MAN 0
#define USE_MAN(...)
#define CFG_MDEV 0
#define USE_MDEV(...)
#define CFG_MDEV_CONF 0
#define USE_MDEV_CONF(...)
#define CFG_MKE2FS 0
#define USE_MKE2FS(...)
#define CFG_MKE2FS_JOURNAL 0
#define USE_MKE2FS_JOURNAL(...)
#define CFG_MKE2FS_GEN 0
#define USE_MKE2FS_GEN(...)
#define CFG_MKE2FS_LABEL 0
#define USE_MKE2FS_LABEL(...)
#define CFG_MKE2FS_EXTENDED 0
#define USE_MKE2FS_EXTENDED(...)
#define CFG_MODPROBE 0
#define USE_MODPROBE(...)
#define CFG_MORE 0
#define USE_MORE(...)
#define CFG_OPENVT 0
#define USE_OPENVT(...)
#define CFG_DEALLOCVT 0
#define USE_DEALLOCVT(...)
#define CFG_ROUTE 0
#define USE_ROUTE(...)
#define CFG_SH 1
#define USE_SH(...) __VA_ARGS__
#define CFG_CD 0
#define USE_CD(...)
#define CFG_DECLARE 0
#define USE_DECLARE(...)
#define CFG_EXIT 0
#define USE_EXIT(...)
#define CFG_SET 0
#define USE_SET(...)
#define CFG_UNSET 0
#define USE_UNSET(...)
#define CFG_EVAL 0
#define USE_EVAL(...)
#define CFG_EXEC 0
#define USE_EXEC(...)
#define CFG_EXPORT 0
#define USE_EXPORT(...)
#define CFG_JOBS 0
#define USE_JOBS(...)
#define CFG_LOCAL 0
#define USE_LOCAL(...)
#define CFG_SHIFT 0
#define USE_SHIFT(...)
#define CFG_SOURCE 0
#define USE_SOURCE(...)
#define CFG_WAIT 0
#define USE_WAIT(...)
#define CFG_STRACE 0
#define USE_STRACE(...)
#define CFG_STTY 0
#define USE_STTY(...)
#define CFG_SULOGIN 0
#define USE_SULOGIN(...)
#define CFG_SYSLOGD 0
#define USE_SYSLOGD(...)
#define CFG_TCPSVD 0
#define USE_TCPSVD(...)
#define CFG_TELNET 0
#define USE_TELNET(...)
#define CFG_TELNETD 0
#define USE_TELNETD(...)
#define CFG_TFTP 0
#define USE_TFTP(...)
#define CFG_TFTPD 0
#define USE_TFTPD(...)
#define CFG_TR 0
#define USE_TR(...)
#define CFG_TRACEROUTE 0
#define USE_TRACEROUTE(...)
#define CFG_USERADD 0
#define USE_USERADD(...)
#define CFG_USERDEL 0
#define USE_USERDEL(...)
#define CFG_VI 0
#define USE_VI(...)
#define CFG_WGET 1
#define USE_WGET(...) __VA_ARGS__
#define CFG_WGET_LIBTLS 0
#define USE_WGET_LIBTLS(...)
#define CFG_WGET_OPENSSL 0
#define USE_WGET_OPENSSL(...)
#define CFG_XZCAT 0
#define USE_XZCAT(...)
#define CFG_ACPI 0
#define USE_ACPI(...)
#define CFG_ASCII 1
#define USE_ASCII(...) __VA_ARGS__
#define CFG_UNICODE 0
#define USE_UNICODE(...)
#define CFG_BASE64 1
#define USE_BASE64(...) __VA_ARGS__
#define CFG_BASE32 0
#define USE_BASE32(...)
#define CFG_BLKDISCARD 0
#define USE_BLKDISCARD(...)
#define CFG_BLKID 0
#define USE_BLKID(...)
#define CFG_FSTYPE 0
#define USE_FSTYPE(...)
#define CFG_BLOCKDEV 0
#define USE_BLOCKDEV(...)
#define CFG_BUNZIP2 0
#define USE_BUNZIP2(...)
#define CFG_BZCAT 0
#define USE_BZCAT(...)
#define CFG_CHCON 0
#define USE_CHCON(...)
#define CFG_CHROOT 0
#define USE_CHROOT(...)
#define CFG_CHRT 0
#define USE_CHRT(...)
#define CFG_CHVT 0
#define USE_CHVT(...)
#define CFG_CLEAR 1
#define USE_CLEAR(...) __VA_ARGS__
#define CFG_COUNT 1
#define USE_COUNT(...) __VA_ARGS__
#define CFG_DEVMEM 0
#define USE_DEVMEM(...)
#define CFG_DOS2UNIX 1
#define USE_DOS2UNIX(...) __VA_ARGS__
#define CFG_UNIX2DOS 1
#define USE_UNIX2DOS(...) __VA_ARGS__
#define CFG_EJECT 0
#define USE_EJECT(...)
#define CFG_FACTOR 1
#define USE_FACTOR(...) __VA_ARGS__
#define CFG_FALLOCATE 1
#define USE_FALLOCATE(...) __VA_ARGS__
#define CFG_FLOCK 1
#define USE_FLOCK(...) __VA_ARGS__
#define CFG_FMT 1
#define USE_FMT(...) __VA_ARGS__
#define CFG_FREE 0
#define USE_FREE(...)
#define CFG_FREERAMDISK 0
#define USE_FREERAMDISK(...)
#define CFG_FSFREEZE 0
#define USE_FSFREEZE(...)
#define CFG_FSYNC 0
#define USE_FSYNC(...)
#define CFG_HELP 1
#define USE_HELP(...) __VA_ARGS__
#define CFG_HEXEDIT 1
#define USE_HEXEDIT(...) __VA_ARGS__
#define CFG_HWCLOCK 0
#define USE_HWCLOCK(...)
#define CFG_I2CDETECT 0
#define USE_I2CDETECT(...)
#define CFG_I2CDUMP 0
#define USE_I2CDUMP(...)
#define CFG_I2CGET 0
#define USE_I2CGET(...)
#define CFG_I2CSET 0
#define USE_I2CSET(...)
#define CFG_INOTIFYD 0
#define USE_INOTIFYD(...)
#define CFG_INSMOD 0
#define USE_INSMOD(...)
#define CFG_IONICE 0
#define USE_IONICE(...)
#define CFG_IORENICE 0
#define USE_IORENICE(...)
#define CFG_LOGIN 0
#define USE_LOGIN(...)
#define CFG_LOSETUP 0
#define USE_LOSETUP(...)
#define CFG_LSATTR 0
#define USE_LSATTR(...)
#define CFG_CHATTR 0
#define USE_CHATTR(...)
#define CFG_LSMOD 0
#define USE_LSMOD(...)
#define CFG_LSPCI 0
#define USE_LSPCI(...)
#define CFG_LSPCI_TEXT 0
#define USE_LSPCI_TEXT(...)
#define CFG_LSUSB 0
#define USE_LSUSB(...)
#define CFG_MAKEDEVS 0
#define USE_MAKEDEVS(...)
#define CFG_MCOOKIE 0
#define USE_MCOOKIE(...)
#define CFG_MIX 0
#define USE_MIX(...)
#define CFG_MKPASSWD 0
#define USE_MKPASSWD(...)
#define CFG_MKSWAP 0
#define USE_MKSWAP(...)
#define CFG_MODINFO 0
#define USE_MODINFO(...)
#define CFG_MOUNTPOINT 0
#define USE_MOUNTPOINT(...)
#define CFG_NBD_CLIENT 0
#define USE_NBD_CLIENT(...)
#define CFG_UNSHARE 0
#define USE_UNSHARE(...)
#define CFG_NSENTER 0
#define USE_NSENTER(...)
#define CFG_ONEIT 0
#define USE_ONEIT(...)
#define CFG_PARTPROBE 0
#define USE_PARTPROBE(...)
#define CFG_PIVOT_ROOT 0
#define USE_PIVOT_ROOT(...)
#define CFG_PMAP 0
#define USE_PMAP(...)
#define CFG_PRINTENV 1
#define USE_PRINTENV(...) __VA_ARGS__
#define CFG_PWDX 1
#define USE_PWDX(...) __VA_ARGS__
#define CFG_PWGEN 0
#define USE_PWGEN(...)
#define CFG_READAHEAD 0
#define USE_READAHEAD(...)
#define CFG_READELF 0
#define USE_READELF(...)
#define CFG_READLINK 1
#define USE_READLINK(...) __VA_ARGS__
#define CFG_REALPATH 1
#define USE_REALPATH(...) __VA_ARGS__
#define CFG_REBOOT 0
#define USE_REBOOT(...)
#define CFG_RESET 0
#define USE_RESET(...)
#define CFG_REV 1
#define USE_REV(...) __VA_ARGS__
#define CFG_RMMOD 0
#define USE_RMMOD(...)
#define CFG_RTCWAKE 0
#define USE_RTCWAKE(...)
#define CFG_SETFATTR 0
#define USE_SETFATTR(...)
#define CFG_SETSID 1
#define USE_SETSID(...) __VA_ARGS__
#define CFG_SHA3SUM 0
#define USE_SHA3SUM(...)
#define CFG_SHRED 0
#define USE_SHRED(...)
#define CFG_STAT 1
#define USE_STAT(...) __VA_ARGS__
#define CFG_SWAPOFF 0
#define USE_SWAPOFF(...)
#define CFG_SWAPON 0
#define USE_SWAPON(...)
#define CFG_SWITCH_ROOT 0
#define USE_SWITCH_ROOT(...)
#define CFG_SYSCTL 0
#define USE_SYSCTL(...)
#define CFG_TAC 1
#define USE_TAC(...) __VA_ARGS__
#define CFG_NPROC 0
#define USE_NPROC(...)
#define CFG_TASKSET 0
#define USE_TASKSET(...)
#define CFG_TIMEOUT 1
#define USE_TIMEOUT(...) __VA_ARGS__
#define CFG_TRUNCATE 1
#define USE_TRUNCATE(...) __VA_ARGS__
#define CFG_UCLAMPSET 0
#define USE_UCLAMPSET(...)
#define CFG_UPTIME 0
#define USE_UPTIME(...)
#define CFG_USLEEP 1
#define USE_USLEEP(...) __VA_ARGS__
#define CFG_UUIDGEN 1
#define USE_UUIDGEN(...) __VA_ARGS__
#define CFG_VCONFIG 0
#define USE_VCONFIG(...)
#define CFG_VMSTAT 0
#define USE_VMSTAT(...)
#define CFG_W 1
#define USE_W(...) __VA_ARGS__
#define CFG_WATCH 1
#define USE_WATCH(...) __VA_ARGS__
#define CFG_WATCHDOG 0
#define USE_WATCHDOG(...)
#define CFG_WHICH 1
#define USE_WHICH(...) __VA_ARGS__
#define CFG_XXD 1
#define USE_XXD(...) __VA_ARGS__
#define CFG_YES 1
#define USE_YES(...) __VA_ARGS__
#define CFG_FTPGET 1
#define USE_FTPGET(...) __VA_ARGS__
#define CFG_FTPPUT 1
#define USE_FTPPUT(...) __VA_ARGS__
#define CFG_HOST 0
#define USE_HOST(...)
#define CFG_IFCONFIG 0
#define USE_IFCONFIG(...)
#define CFG_MICROCOM 1
#define USE_MICROCOM(...) __VA_ARGS__
#define CFG_NETCAT 1
#define USE_NETCAT(...) __VA_ARGS__
#define CFG_NETCAT_LISTEN 1
#define USE_NETCAT_LISTEN(...) __VA_ARGS__
#define CFG_NETSTAT 0
#define USE_NETSTAT(...)
#define CFG_PING 0
#define USE_PING(...)
#define CFG_RFKILL 0
#define USE_RFKILL(...)
#define CFG_SNTP 0
#define USE_SNTP(...)
#define CFG_TUNCTL 0
#define USE_TUNCTL(...)
#define CFG_DMESG 0
#define USE_DMESG(...)
#define CFG_GZIP 0
#define USE_GZIP(...)
#define CFG_GUNZIP 0
#define USE_GUNZIP(...)
#define CFG_ZCAT 0
#define USE_ZCAT(...)
#define CFG_HOSTNAME 1
#define USE_HOSTNAME(...) __VA_ARGS__
#define CFG_DNSDOMAINNAME 0
#define USE_DNSDOMAINNAME(...)
#define CFG_KILLALL 0
#define USE_KILLALL(...)
#define CFG_MD5SUM 1
#define USE_MD5SUM(...) __VA_ARGS__
#define CFG_SHA1SUM 1
#define USE_SHA1SUM(...) __VA_ARGS__
#define CFG_SHA224SUM 0
#define USE_SHA224SUM(...)
#define CFG_SHA256SUM 0
#define USE_SHA256SUM(...)
#define CFG_SHA384SUM 0
#define USE_SHA384SUM(...)
#define CFG_SHA512SUM 0
#define USE_SHA512SUM(...)
#define CFG_MKNOD 0
#define USE_MKNOD(...)
#define CFG_MKNOD_Z 0
#define USE_MKNOD_Z(...)
#define CFG_MKTEMP 1
#define USE_MKTEMP(...) __VA_ARGS__
#define CFG_MOUNT 0
#define USE_MOUNT(...)
#define CFG_PASSWD 0
#define USE_PASSWD(...)
#define CFG_PASSWD_SAD 0
#define USE_PASSWD_SAD(...)
#define CFG_PIDOF 0
#define USE_PIDOF(...)
#define CFG_SEQ 1
#define USE_SEQ(...) __VA_ARGS__
#define CFG_SU 0
#define USE_SU(...)
#define CFG_SYNC 0
#define USE_SYNC(...)
#define CFG_UMOUNT 0
#define USE_UMOUNT(...)
#define CFG_DEMO_MANY_OPTIONS 0
#define USE_DEMO_MANY_OPTIONS(...)
#define CFG_DEMO_NUMBER 0
#define USE_DEMO_NUMBER(...)
#define CFG_DEMO_SCANKEY 0
#define USE_DEMO_SCANKEY(...)
#define CFG_DEMO_UTF8TOWC 0
#define USE_DEMO_UTF8TOWC(...)
#define CFG_HELLO 0
#define USE_HELLO(...)
#define CFG_HOSTID 0
#define USE_HOSTID(...)
#define CFG_LOGPATH 0
#define USE_LOGPATH(...)
#define CFG_SKELETON 0
#define USE_SKELETON(...)
#define CFG_SKELETON_ALIAS 0
#define USE_SKELETON_ALIAS(...)
#define CFG_GETENFORCE 0
#define USE_GETENFORCE(...)
#define CFG_LOAD_POLICY 0
#define USE_LOAD_POLICY(...)
#define CFG_LOG 0
#define USE_LOG(...)
#define CFG_RESTORECON 0
#define USE_RESTORECON(...)
#define CFG_RUNCON 0
#define USE_RUNCON(...)
#define CFG_SENDEVENT 0
#define USE_SENDEVENT(...)
#define CFG_SETENFORCE 0
#define USE_SETENFORCE(...)
#define CFG_TOYBOX 1
#define USE_TOYBOX(...) __VA_ARGS__
#define CFG_TOYBOX_SUID 1
#define USE_TOYBOX_SUID(...) __VA_ARGS__
#define CFG_TOYBOX_LSM_NONE 1
#define USE_TOYBOX_LSM_NONE(...) __VA_ARGS__
#define CFG_TOYBOX_SELINUX 0
#define USE_TOYBOX_SELINUX(...)
#define CFG_TOYBOX_SMACK 0
#define USE_TOYBOX_SMACK(...)
#define CFG_TOYBOX_LIBCRYPTO 0
#define USE_TOYBOX_LIBCRYPTO(...)
#define CFG_TOYBOX_LIBZ 0
#define USE_TOYBOX_LIBZ(...)
#define CFG_TOYBOX_FLOAT 1
#define USE_TOYBOX_FLOAT(...) __VA_ARGS__
#define CFG_TOYBOX_HELP 1
#define USE_TOYBOX_HELP(...) __VA_ARGS__
#define CFG_TOYBOX_HELP_DASHDASH 1
#define USE_TOYBOX_HELP_DASHDASH(...) __VA_ARGS__
#define CFG_TOYBOX_FREE 0
#define USE_TOYBOX_FREE(...)
#define CFG_TOYBOX_NORECURSE 0
#define USE_TOYBOX_NORECURSE(...)
#define CFG_TOYBOX_DEBUG 0
#define USE_TOYBOX_DEBUG(...)
#define CFG_TOYBOX_PEDANTIC_ARGS 0
#define USE_TOYBOX_PEDANTIC_ARGS(...)
#define CFG_TOYBOX_UID_SYS 100
#define CFG_TOYBOX_UID_USR 500
#define CFG_TOYBOX_FORCE_NOMMU 0
#define USE_TOYBOX_FORCE_NOMMU(...)
